﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TraceStepHandler : MonoBehaviour {

	public List<AnimateArrow> allSteps = new List<AnimateArrow>();
	public bool complete;
	public List<AnimateArrow> completedSteps = new List<AnimateArrow>();
	private int counter = 0;
	private AnimateArrow currentStep;
	private GameObject finalStep;
	private bool fadeTrigger = true;
	private bool aTouched = false;
	private bool bTouched = false;
	public GameObject trail;
	private GameObject texturedLetter;

	//public GameObject letter;

	// Use this for initialization
	void Start () {
		texturedLetter = GameObject.Find ("TexturedLetter");
		counter = 0;
		complete = false;
// 		StartCoroutine (FadeTo (0f, 1.5f));
//		finalStep = steps [steps.Length];
	
	}

	void Complete () {
		//Application.LoadLevel ("selection");
		Debug.Log ("complete function");
		texturedLetter.GetComponent<FadeTo> ().fadeFinish = true;
	}

	
	// Update is called once per frame
	void Update () {	
		if (aTouched && bTouched) {
			Debug.Log ("a and b, finished");
			currentStep.ClearArrows();
			aTouched=false;
			bTouched=false;
			if (counter + 1 < allSteps.Count){
				counter++;
				allSteps [counter].gameObject.SetActive (true);
			}
			else if (counter + 1 >= allSteps.Count){
				Complete ();	
				complete = true;
			}
		}
		currentStep = allSteps [counter];
//		Debug.Log("atouched");
		if (currentStep.pointA.touched) {
		//	trail.GetComponent<Renderer>().enabled = true;
			aTouched = true;
			if (currentStep.pointB.touched) {
				Debug.Log("btouched");
				bTouched= true;
			}
		}
		else if (!currentStep.pointA.touched) {
		//	trail.GetComponent<Renderer>().enabled = false;
		}

	}
}