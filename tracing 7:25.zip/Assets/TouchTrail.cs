﻿using UnityEngine;
using System.Collections;

public class TouchTrail : MonoBehaviour {

	public GameObject trail;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTouchDown () {
		//GameObject f = Instantiate(trail, new Vector3(trail.transform.position.x, trail.transform.position.y, trail.transform.position.z + 1), trail.transform.rotation) as GameObject;
		Debug.Log ("touchin");
	}
}
