﻿using UnityEngine;
using System.Collections;

public class SoundArray : MonoBehaviour {

	public AudioClip[] englishSounds;
	public AudioClip[] spanishSounds;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
