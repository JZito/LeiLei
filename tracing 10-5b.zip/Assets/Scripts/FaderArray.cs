﻿using UnityEngine;
using System.Collections;

public class FaderArray : MonoBehaviour {

	public GameObject[] faders;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
