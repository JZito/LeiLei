﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LetterStart : MonoBehaviour {

	public TraceStepHandler[] letters;
	private int counter;
	public GameObject letter;

	// Use this for initialization
	void Start () {
		counter = 0;
	}
	
	// Update is called once per frame
	void Update () {

	}
}
