﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIManager : MonoBehaviour {

//	public GameObject gameplayScreen;
//	public GameObject selectionScreen;
	public bool spanish;
	public GameObject aboutPanelSpanish;
	public GameObject aboutPanelEnglish;
	private int languageTicker = 0;
	public GameObject language;
	public Sprite englishSprite;
	public Sprite spanishSprite;

	// Use this for initialization

	void Awake () {
		language = GameObject.Find ("Language");
		languageTicker = PlayerPrefs.GetInt ("Spanish");
		if (languageTicker == 0) {
			language.GetComponent<Image>().sprite = spanishSprite;
			spanish = true;
		} 
		else if (languageTicker == 1) {
			language.GetComponent<Image>().sprite = englishSprite;
			spanish = false;
		}
	}
	void Start () {

		//GameObject aboutPanel = GameObject.FindGameObjectWithTag ("AboutPanel");
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void BackToSelection() {
		Application.LoadLevel ("selection");
	}

	public void AboutPageOnOff() {
		if (!spanish) {
			if (!aboutPanelEnglish.activeSelf && !aboutPanelSpanish.activeSelf) {
				aboutPanelEnglish.gameObject.SetActive (true);		
			} 
			else if (aboutPanelEnglish.activeSelf || aboutPanelSpanish.activeSelf) {
				aboutPanelSpanish.gameObject.SetActive(false);
				aboutPanelEnglish.gameObject.SetActive(false);	
			}
		}
		else if (spanish){
			if (!aboutPanelSpanish.activeSelf && !aboutPanelEnglish.activeSelf) {
				aboutPanelSpanish.gameObject.SetActive (true);		
			} 
			else if (aboutPanelSpanish.activeSelf || aboutPanelEnglish.activeSelf) {
				aboutPanelSpanish.gameObject.SetActive(false);	
				aboutPanelEnglish.gameObject.SetActive(false);
			}
		}
	}

	public void LanguageButton () {
		if (languageTicker == 0){
			PlayerPrefs.SetInt("Spanish", 1);
			languageTicker = 1;
			language.GetComponent<Image>().sprite = englishSprite;
			spanish = false;
		}
		else if (languageTicker == 1) {
			PlayerPrefs.SetInt("Spanish", 0);
			languageTicker = 0;
			language.GetComponent<Image>().sprite = spanishSprite;
			spanish = true;
		}
	}
}
